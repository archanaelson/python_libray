import tkinter as tk


root = tk.Tk()
root.title("Balance Enquiry")
root.geometry("800x450")
root.resizable(False, False)


bg = tk.Frame(root, bg="black")
bg.place(x=0, y=0, width=800, height=450)

heading = tk.Label(
    bg,
    text="BANK MANAGEMENT SYSTEM",
    font=("Arial", 22, "bold"),
    fg="red",
    bg="black"
)
heading.place(x=170, y=20)


lbl_acc = tk.Label(bg, text="Account No", font=("Arial", 14),
                   fg="#00ffff", bg="black")
lbl_acc.place(x=120, y=100)

lbl_name = tk.Label(bg, text="Name of the Account Holder",
                    font=("Arial", 14), fg="#00ffff", bg="black")
lbl_name.place(x=120, y=150)

lbl_type = tk.Label(bg, text="Type of Account",
                    font=("Arial", 14), fg="#00ffff", bg="black")
lbl_type.place(x=120, y=200)

lbl_balance = tk.Label(bg, text="Current Balance",
                       font=("Arial", 14), fg="#00ffff", bg="black")
lbl_balance.place(x=120, y=250)


ent_acc = tk.Entry(bg, font=("Arial", 14))
ent_acc.place(x=420, y=100, width=220, height=30)

ent_name = tk.Entry(bg, font=("Arial", 14))
ent_name.place(x=420, y=150, width=220, height=30)

ent_type = tk.Entry(bg, font=("Arial", 14))
ent_type.place(x=420, y=200, width=220, height=30)

ent_balance = tk.Entry(bg, font=("Arial", 14))
ent_balance.place(x=420, y=250, width=220, height=30)


btn_get = tk.Button(
    bg,
    text="Get Balance",
    font=("Arial", 12, "bold"),
    bg="gray",
    fg="#00ffff"
)
btn_get.place(x=660, y=100, width=110, height=35)


btn_back = tk.Button(
    bg,
    text="Back",
    font=("Arial", 14, "bold"),
    bg="gray",
    fg="#00ffff"
)
btn_back.place(x=350, y=330, width=100, height=40)

root.mainloop()
