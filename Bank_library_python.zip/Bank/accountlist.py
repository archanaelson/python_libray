import tkinter as tk
from tkinter import ttk


root = tk.Tk()
root.title("Account List")
root.geometry("800x450")
root.resizable(False, False)


bg_frame = tk.Frame(root, bg="#00e5e5")
bg_frame.place(x=0, y=0, width=800, height=450)


search_entry = tk.Entry(bg_frame, font=("Arial", 12))
search_entry.place(x=220, y=20, width=250, height=30)


search_btn = tk.Button(bg_frame, text="Search", font=("Arial", 11))
search_btn.place(x=480, y=20, width=80, height=30)


table_frame = tk.Frame(bg_frame, bg="white")
table_frame.place(x=40, y=70, width=720, height=330)

columns = ("acc_no", "name", "type", "deposit")

tree = ttk.Treeview(
    table_frame,
    columns=columns,
    show="headings",
    height=12
)


tree.heading("acc_no", text="Account_No")
tree.heading("name", text="Account Holder Name")
tree.heading("type", text="Type of Account")
tree.heading("deposit", text="Initial Deposit")

tree.column("acc_no", width=120, anchor="center")
tree.column("name", width=220, anchor="center")
tree.column("type", width=160, anchor="center")
tree.column("deposit", width=160, anchor="center")

tree.place(x=0, y=0, width=720, height=330)



root.mainloop()
