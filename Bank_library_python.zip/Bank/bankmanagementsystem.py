import tkinter as tk
root = tk.Tk()
root.title("Welcome")
root.geometry("900x520")
root.configure(bg="black")
root.resizable(False, False)
btn= tk.Button(
    root,
    text="WELCOME",
    font=("Arial", 16, "bold"),
    bg="gray",
    fg="cyan",
    width=40,
    
)
btn.place(x=200, y=100)
root.mainloop()
