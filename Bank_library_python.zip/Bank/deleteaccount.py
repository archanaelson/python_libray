import tkinter as tk

root = tk.Tk()
root.title("Delete Account")
root.geometry("800x450")
root.configure(bg="black")
root.resizable(False, False)

title = tk.Label(
    root,
    text="BANK MANAGEMENT SYSTEM",
    font=("Arial", 22, "bold"),
    fg="red",
    bg="black"
)
title.place(x=180, y=20)

lbl_font = ("Arial", 14, "bold")

lbl_acc = tk.Label(root, text="Account No",
                   font=lbl_font, fg="cyan", bg="black")
lbl_acc.place(x=120, y=110)

lbl_name = tk.Label(root, text="Name of the Account Holder",
                    font=lbl_font, fg="cyan", bg="black")
lbl_name.place(x=120, y=160)

lbl_type = tk.Label(root, text="Type of Account",
                    font=lbl_font, fg="cyan", bg="black")
lbl_type.place(x=120, y=210)

ent_acc = tk.Entry(root, width=30, font=("Arial", 12))
ent_acc.place(x=420, y=110)

ent_name = tk.Entry(root, width=30, font=("Arial", 12))
ent_name.place(x=420, y=160)

ent_type = tk.Entry(root, width=30, font=("Arial", 12))
ent_type.place(x=420, y=210)

btn_get = tk.Button(root, text="Get Details",
                    font=("Arial", 12, "bold"),
                    bg="gray", fg="cyan", width=12)
btn_get.place(x=650, y=105)

btn_delete = tk.Button(root, text="Delete Account",
                       font=("Arial", 13, "bold"),
                       bg="gray", fg="cyan", width=15)
btn_delete.place(x=250, y=300)

btn_back = tk.Button(root, text="Back",
                     font=("Arial", 13, "bold"),
                     bg="gray", fg="cyan", width=15,
                     command=root.destroy)
btn_back.place(x=450, y=300)

root.mainloop()
