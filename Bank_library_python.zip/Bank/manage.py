import tkinter as tk

root = tk.Tk()
root.title("Bank Management System")
root.geometry("600x700")
root.configure(bg="black")
root.resizable(False, False)

title = tk.Label(
    root,
    text="BANK MANAGEMENT SYSTEM",
    fg="red",
    bg="black",
    font=("Arial", 22, "bold")
)
title.place(x=90, y=40)

btn_font = ("Arial", 14, "bold")
btn_width = 18
btn_height = 2
btn_bg = "blue"
btn_fg = "white"

btn_new = tk.Button(root, text="New Account",
                    bg=btn_bg, fg=btn_fg,
                    font=btn_font, width=btn_width, height=btn_height)
btn_new.place(x=200, y=120)

btn_dep = tk.Button(root, text="Deposit",
                    bg=btn_bg, fg=btn_fg,
                    font=btn_font, width=btn_width, height=btn_height)
btn_dep.place(x=200, y=180)

btn_with = tk.Button(root, text="Withdrawal",
                     bg=btn_bg, fg=btn_fg,
                     font=btn_font, width=btn_width, height=btn_height)
btn_with.place(x=200, y=240)

btn_bal = tk.Button(root, text="Balance Enquiry",
                    bg=btn_bg, fg=btn_fg,
                    font=btn_font, width=btn_width, height=btn_height)
btn_bal.place(x=200, y=300)

btn_update = tk.Button(root, text="Update Details",
                       bg=btn_bg, fg=btn_fg,
                       font=btn_font, width=btn_width, height=btn_height)
btn_update.place(x=200, y=360)

btn_delete = tk.Button(root, text="Delete Account",
                       bg=btn_bg, fg=btn_fg,
                       font=btn_font, width=btn_width, height=btn_height)
btn_delete.place(x=200, y=420)

btn_list = tk.Button(root, text="Account List",
                     bg=btn_bg, fg=btn_fg,
                     font=btn_font, width=btn_width, height=btn_height)
btn_list.place(x=200, y=480)

btn_exit = tk.Button(root, text="Exit",
                     bg=btn_bg, fg=btn_fg,
                     font=btn_font, width=btn_width, height=btn_height,
                     command=root.destroy)
btn_exit.place(x=200, y=540)

root.mainloop()
