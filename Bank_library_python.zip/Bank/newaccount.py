import tkinter as tk

root = tk.Tk()
root.title("New Account")
root.geometry("900x480")
root.configure(bg="black")
root.resizable(False, False)

title = tk.Label(
    root,
    text="BANK MANAGEMENT SYSTEM",
    font=("Arial", 22, "bold"),
    fg="red",
    bg="black"
)
title.place(x=230, y=20)

lbl_font = ("Arial", 14, "bold")

tk.Label(root, text="Account No",
         font=lbl_font, fg="cyan", bg="black").place(x=150, y=120)

tk.Label(root, text="Name of the Account Holder",
         font=lbl_font, fg="cyan", bg="black").place(x=150, y=170)

tk.Label(root, text="Type of Account",
         font=lbl_font, fg="cyan", bg="black").place(x=150, y=220)

tk.Label(root, text="Initial Deposit",
         font=lbl_font, fg="cyan", bg="black").place(x=150, y=270)

ent_acc = tk.Entry(root, width=32, font=("Arial", 12))
ent_acc.place(x=480, y=120)

ent_name = tk.Entry(root, width=32, font=("Arial", 12))
ent_name.place(x=480, y=170)

ent_deposit = tk.Entry(root, width=32, font=("Arial", 12))
ent_deposit.place(x=480, y=270)

acc_type = tk.StringVar(value="Savings")

rb_savings = tk.Radiobutton(
    root, text="Savings",
    variable=acc_type, value="Savings",
    font=("Arial", 12, "bold"),
    fg="cyan", bg="black",
    activebackground="black",
    activeforeground="cyan",
    selectcolor="black"
)
rb_savings.place(x=480, y=220)

rb_current = tk.Radiobutton(
    root, text="Current",
    variable=acc_type, value="Current",
    font=("Arial", 12, "bold"),
    fg="cyan", bg="black",
    activebackground="black",
    activeforeground="cyan",
    selectcolor="black"
)
rb_current.place(x=600, y=220)

btn_save = tk.Button(
    root, text="Save",
    font=("Arial", 13, "bold"),
    bg="gray", fg="cyan",
    width=12
)
btn_save.place(x=300, y=360)

btn_cancel = tk.Button(
    root, text="Cancel",
    font=("Arial", 13, "bold"),
    bg="gray", fg="cyan",
    width=12,
    command=root.destroy
)
btn_cancel.place(x=480, y=360)

root.mainloop()
