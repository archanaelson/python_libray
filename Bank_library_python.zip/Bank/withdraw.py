import tkinter as tk

root = tk.Tk()
root.title("Withdrawal")
root.geometry("950x520")
root.configure(bg="black")
root.resizable(False, False)

title = tk.Label(
    root,
    text="BANK MANAGEMENT SYSTEM",
    font=("Arial", 22, "bold"),
    fg="red",
    bg="black"
)
title.place(x=230, y=20)

lbl_font = ("Arial", 14, "bold")

labels = [
    "Account No",
    "Name of the Account Holder",
    "Type of Account",
    "Current Balance",
    "Withdrawal Amount"
]

y = 120
for text in labels:
    tk.Label(root, text=text,
             font=lbl_font, fg="cyan", bg="black").place(x=140, y=y)
    y += 55

entries = []
y = 120
for _ in range(5):
    ent = tk.Entry(root, width=32, font=("Arial", 12))
    ent.place(x=480, y=y)
    entries.append(ent)
    y += 55

btn_get = tk.Button(
    root, text="Get Details",
    font=("Arial", 12, "bold"),
    bg="gray", fg="cyan",
    width=12
)
btn_get.place(x=760, y=115)

btn_save = tk.Button(
    root, text="Save",
    font=("Arial", 13, "bold"),
    bg="gray", fg="cyan",
    width=12
)
btn_save.place(x=260, y=420)

btn_update = tk.Button(
    root, text="Update",
    font=("Arial", 13, "bold"),
    bg="gray", fg="cyan",
    width=12
)
btn_update.place(x=410, y=420)

btn_back = tk.Button(
    root, text="Back",
    font=("Arial", 13, "bold"),
    bg="gray", fg="cyan",
    width=12,
    command=root.destroy
)
btn_back.place(x=560, y=420)

root.mainloop()
