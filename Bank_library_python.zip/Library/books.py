from tkinter import *
top=Tk()
top.geometry("1500x1500")
top.title("books")
book=Label(top,text="BOOKS DETAILS",font=('time',20)).place(x=550,y=30)

bookname=Label(top,text="BOOK NAME",font=('time',20)).place(x=300,y=100)
e1=Entry(top ,font=('time',20)).place(x=600,y=100)

author=Label(top,text="AUTHOR",font=('time',20)).place(x=300,y=150)
e2=Entry(top ,font=('time',20)).place(x=600,y=150)

publisher=Label(top,text="PUBLISHER",font=('time',20)).place(x=300,y=200)
e3=Entry(top ,font=('time',20)).place(x=600,y=200)

price=Label(top,text="PRICE",font=('time',20)).place(x=300,y=250)
e4=Entry(top ,font=('time',20)).place(x=600,y=250)

quantity=Label(top,text="QUANTITY",font=('time',20)).place(x=300,y=300)
e5=Entry(top ,font=('time',20)).place(x=600,y=300)

save=Button(top,text="SAVE",font=('time',20)).place(x=200,y=400)
reset=Button(top,text="RESET",font=('time',20)).place(x=400,y=400)
edit=Button(top,text="EDIT",font=('time',20)).place(x=600,y=400)
delete=Button(top,text="DELETE",font=('time',20)).place(x=800,y=400)
logout=Button(top,text="LOGOUT",font=('time',20)).place(x=1000,y=400)
top.mainloop()
