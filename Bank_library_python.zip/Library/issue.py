from tkinter import *
from tkinter.ttk import Combobox

top=Tk()
top.geometry("1500x1500")
top.title("issue")
issuebook=Label(top,text="ISSUE BOOKS",font=('time',20)).place(x=550,y=30)

studid=Label(top,text="Student Id",font=('time',20)).place(x=300,y=100)
stuid=['1','2','3','4','5']
combo2 = Combobox(top, values=stuid, font=('times', 20), state="readonly")
combo2.set("Select Id")
combo2.place(x=600, y=100)


studname=Label(top,text="Student Name",font=('time',20)).place(x=300,y=150)
e1=Entry(top ,font=('time',20)).place(x=600,y=150)

bookid=Label(top,text="Book Id",font=('time',20)).place(x=300,y=200)
book=["tamil","english","maths","science","social"]
combo1 = Combobox(top, values=book, font=('times', 20), state="readonly")
combo1.set("Select Department")
combo1.place(x=600, y=200)


bookname=Label(top,text="Book Name",font=('time',20)).place(x=300,y=250)

e2=Entry(top ,font=('time',20)).place(x=600,y=250)

issuedate=Label(top,text="Issue Date",font=('time',20)).place(x=300,y=300)
e3=Entry(top ,font=('time',20)).place(x=600,y=300)

save=Button(top,text="SAVE",font=('time',20)).place(x=200,y=350)
reset=Button(top,text="RESET",font=('time',20)).place(x=400,y=350)
edit=Button(top,text="EDIT",font=('time',20)).place(x=600,y=350)
delete=Button(top,text="DELETE",font=('time',20)).place(x=800,y=350)
logout=Button(top,text="LOGOUT",font=('time',20)).place(x=1100,y=350)
top.mainloop()
