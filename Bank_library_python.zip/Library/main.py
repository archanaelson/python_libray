from tkinter import *
from tkinter.ttk import Combobox,Treeview
import mysql.connector
top=Tk()
top.geometry("1500x1500")
top.title("user")
def user():
    fr=Frame(top,highlightbackground="red",highlightthickness=3)
    fr.config(height=400,width=900)
    fr.pack_propagate(False)
    fr.pack(pady=30)
    login=Label(fr,text="USER LOGIN",font=('time',20)).place(x=300,y=70)
    username=Label(fr,text="USERNAME",font=('time',20)).place(x=200,y=150)
    e1=Entry(fr ,font=('time',20)).place(x=400,y=150)
    password=Label(fr,text="PASSWORD",font=('time',20)).place(x=200,y=200)
    e2=Entry(fr ,font=('time',20)).place(x=400,y=200)
    loginbtn=Button(fr,text="USER",font=('time',20)).place(x=300,y=280)
    adminbtn=Button(fr,text="ADMIN",font=('time',20)).place(x=450,y=280)
# user()
def admin():
    fr=Frame(top,highlightbackground="red",highlightthickness=3)
    fr.config(height=400,width=900)
    fr.pack_propagate(False)
    fr.pack(pady=30)
    login=Label(top,text="ADMIN LOGIN",font=('time',20)).place(x=550,y=50)
    username=Label(top,text="USERNAME",font=('time',20)).place(x=300,y=150)
    e1=Entry(top ,font=('time',20)).place(x=600,y=150)
    password=Label(top,text="PASSWORD",font=('time',20)).place(x=300,y=200)
    e2=Entry(top ,font=('time',20)).place(x=600,y=200)
    adminbtn=Button(top,text="ADMIN",font=('time',20)).place(x=600,y=300)
# admin()
def librarian():
    mydb=mysql.connector.connect(host="localhost",user="root",passwd="",database="library")
    mycursor=mydb.cursor()
    def librariandb():
        sql="INSERT INTO librarian(name,phonenumber,password) VALUES(%s,%s,%s)"
        val=(e1.get(),e2.get(),e3.get())
        mycursor.execute(sql,val)
        mydb.commit()

    fr=Frame(top,highlightbackground="red",highlightthickness=3)
    fr.config(height=500,width=900)
    fr.pack_propagate(False)
    fr.pack(pady=30)

    login=Label(fr,text="LIBRARIAN PAGE",font=('time',20)).place(x=250,y=10)
    name=Label(fr,text="NAME",font=('time',20)).place(x=200,y=50)
    e1=Entry(fr ,font=('time',20))
    e1.place(x=400,y=50)
    phonenumber=Label(fr,text="PHONE NO",font=('time',20)).place(x=200,y=100)
    e2=Entry(fr ,font=('time',20))
    e2.place(x=400,y=100)
    password=Label(fr,text="PASSWORD",font=('time',20)).place(x=200,y=150)
    e3=Entry(fr ,font=('time',20))
    e3.place(x=400,y=150)

    save=Button(fr,text="SAVE",font=('time',20),command=librariandb).place(x=70,y=200)
    reset=Button(fr,text="RESET",font=('time',20)).place(x=190,y=200)
    edit=Button(fr,text="EDIT",font=('time',20)).place(x=330,y=200)
    delete=Button(fr,text="DELETE",font=('time',20)).place(x=430,y=200)
    logout=Button(fr,text="LOGOUT",font=('time',20)).place(x=580,y=200)
    table=Treeview(fr,columns=('id','name','phno','password'))
    table.heading('id',text="Id")
    table.heading('name',text="Name")
    table.heading('phno',text="PhoneNumber")
    table.heading('password',text="Password")
    table.column('id',width=30)
    table.column('name',width=100)
    table.column('phno',width=100)
    table.column('password',width=100)
    table.config(show="headings")
    table.place(x=50,y=270,height=200,width=800)
librarian()

def student():
    mydb=mysql.connector.connect(host="localhost",user="root",passwd="",database="library")
    mycursor=mydb.cursor()
    def studentdb():
        sql="INSERT INTO student(name,department,semester,phonenumber) VALUES(%s,%s,%s,%s)"
        val=(e1.get(),combo1.get(),combo2.get(),e2.get())
        mycursor.execute(sql,val)
        mydb.commit()   
    fr=Frame(top,highlightbackground="red",highlightthickness=3)
    fr.config(height=400,width=900)
    fr.pack_propagate(False)
    fr.pack(pady=30)
    name=Label(fr,text="NAME",font=('time',20)).place(x=300,y=100)
    e1=Entry(fr ,font=('time',20))
    e1.place(x=600,y=100)

    department=Label(fr,text="DEPARTMENT",font=('time',20)).place(x=300,y=150)
    dep=["tamil","english","maths","science","social"]
    combo1 = Combobox(fr, values=dep, font=('times', 20), state="readonly")
    combo1.set("Select Department")
    combo1.place(x=600, y=150)

    semester=Label(fr,text="SEMESTER",font=('time',20)).place(x=300,y=200)
    sem=["first","second","third","fourth","fifth"]
    combo2 = Combobox(fr, values=sem, font=('times', 20), state="readonly")
    combo2.set("Select Semester")
    combo2.place(x=600, y=200)

    password=Label(fr,text="PASSWORD",font=('time',20)).place(x=300,y=250)
    e2=Entry(fr ,font=('time',20))
    e2.place(x=600,y=250)

    save=Button(fr,text="SAVE",font=('time',20),command=studentdb).place(x=300,y=300)
    reset=Button(fr,text="RESET",font=('time',20)).place(x=450,y=300)
    edit=Button(fr,text="EDIT",font=('time',20)).place(x=600,y=300)
    delete=Button(fr,text="DELETE",font=('time',20)).place(x=750,y=300)
    logout=Button(fr,text="LOGOUT",font=('time',20)).place(x=900,y=300)
# student()
def book():
    mydb=mysql.connector.connect(host="localhost",user="root",passwd="",database="library")
    mycursor=mydb.cursor()
    def bookdb():
        sql="INSERT INTO book(bookname,author,publisher,price,quantity) VALUES(%s,%s,%s,%s,%s)"
        val=(e1.get(),e2.get(),e3.get(),e4.get(),e5.get())
        mycursor.execute(sql,val)
        mydb.commit()
    fr=Frame(top,highlightbackground="red",highlightthickness=3)
    fr.config(height=500,width=1000)
    fr.pack_propagate(False)
    fr.pack(pady=30)
    book=Label(fr,text="BOOKS DETAILS",font=('time',20)).place(x=500,y=50)

    bookname=Label(fr,text="BOOK NAME",font=('time',20)).place(x=300,y=100)
    e1=Entry(fr ,font=('time',20))
    e1.place(x=600,y=100)

    author=Label(fr,text="AUTHOR",font=('time',20)).place(x=300,y=150)
    e2=Entry(fr ,font=('time',20))
    e2.place(x=600,y=150)

    publisher=Label(fr,text="PUBLISHER",font=('time',20)).place(x=300,y=200)
    e3=Entry(fr ,font=('time',20))
    e3.place(x=600,y=200)

    price=Label(fr,text="PRICE",font=('time',20)).place(x=300,y=250)
    e4=Entry(fr ,font=('time',20))
    e4.place(x=600,y=250)

    quantity=Label(fr,text="QUANTITY",font=('time',20)).place(x=300,y=300)
    e5=Entry(fr ,font=('time',20))
    e5.place(x=600,y=300)

    save=Button(fr,text="SAVE",font=('time',20),command=bookdb).place(x=200,y=400)
    reset=Button(fr,text="RESET",font=('time',20)).place(x=350,y=400)
    edit=Button(fr,text="EDIT",font=('time',20)).place(x=500,y=400)
    delete=Button(fr,text="DELETE",font=('time',20)).place(x=600,y=400)
    logout=Button(fr,text="LOGOUT",font=('time',20)).place(x=750,y=400)
# book()
def issue():
    mydb=mysql.connector.connect(host="localhost",user="root",passwd="",database="library")
    mycursor=mydb.cursor()
    def issuedb():
        sql="INSERT INTO issue(studentid,studentname,bookid,bookname,issuedate) VALUES(%s,%s,%s,%s,%s)"
        val=(combo2.get(),e1.get(),combo1.get(),e2.get(),e3.get())
        mycursor.execute(sql,val)
        mydb.commit()

    fr=Frame(top,highlightbackground="red",highlightthickness=3)
    fr.config(height=500,width=900)
    fr.pack_propagate(False)
    fr.pack(pady=30)

    issuebook=Label(fr,text="ISSUE BOOKS",font=('time',20)).place(x=550,y=50)

    studid=Label(fr,text="Student Id",font=('time',20)).place(x=300,y=100)
    stuid=['1','2','3','4','5']
    combo2 = Combobox(fr, values=stuid, font=('times', 20), state="readonly")
    combo2.set("Select Id")
    combo2.place(x=600, y=100)


    studname=Label(fr,text="Student Name",font=('time',20)).place(x=300,y=150)
    e1=Entry(fr ,font=('time',20))
    e1.place(x=600,y=150)

    bookid=Label(fr,text="Book Id",font=('time',20)).place(x=300,y=200)
    book=["1","2","3","4","5"]
    combo1 = Combobox(fr, values=book, font=('times', 20), state="readonly")
    combo1.set("Select Department")
    combo1.place(x=600, y=200)


    bookname=Label(fr,text="Book Name",font=('time',20)).place(x=300,y=250)

    e2=Entry(fr ,font=('time',20))
    e2.place(x=600,y=250)

    issuedate=Label(fr,text="Issue Date",font=('time',20)).place(x=300,y=300)
    e3=Entry(fr ,font=('time',20))
    e3.place(x=600,y=300)

    save=Button(fr,text="SAVE",font=('time',20),command=issuedb).place(x=200,y=350)
    reset=Button(fr,text="RESET",font=('time',20)).place(x=350,y=350)
    edit=Button(fr,text="EDIT",font=('time',20)).place(x=500,y=350)
    delete=Button(fr,text="DELETE",font=('time',20)).place(x=600,y=350)
    logout=Button(fr,text="LOGOUT",font=('time',20)).place(x=800,y=350)
# issue()
def return1():
    mydb=mysql.connector.connect(host="localhost",user="root",passwd="",database="library")
    mycursor=mydb.cursor()
    def return1db():
        sql="INSERT INTO return(studentid,studentname,bookid,bookname,issuedate,returndate,fine) VALUES(%s,%s,%s,%s,%s,%s,%s)"
        val=(combo2.get(),e1.get(),combo1.get(),e2.get(),e3.get())
        mycursor.execute(sql,val)
        mydb.commit()
    fr=Frame(top,highlightbackground="red",highlightthickness=3)
    fr.config(height=500,width=900)
    fr.pack_propagate(False)
    fr.pack(pady=30)

    issuebook=Label(top,text="RETURN BOOKS",font=('time',20)).place(x=550,y=50)

    studid=Label(top,text="Student Id",font=('time',20)).place(x=300,y=100)
    stuid=['1','2','3','4','5']
    combo2 = Combobox(top, values=stuid, font=('times', 20), state="readonly")
    combo2.set("Select Id")
    combo2.place(x=600, y=100)


    studname=Label(top,text="Student Name",font=('time',20)).place(x=300,y=150)
    e1=Entry(top ,font=('time',20))
    e1.place(x=600,y=150)

    bookid=Label(top,text="Book Id",font=('time',20)).place(x=300,y=200)
    book=["tamil","english","maths","science","social"]
    combo1 = Combobox(top, values=book, font=('times', 20), state="readonly")
    combo1.set("Select Department")
    combo1.place(x=600, y=200)


    bookname=Label(top,text="Book Name",font=('time',20)).place(x=300,y=250)

    e2=Entry(top ,font=('time',20))
    e2.place(x=600,y=250)

    issuedate=Label(top,text="Issue Date",font=('time',20)).place(x=300,y=300)
    e3=Entry(top ,font=('time',20))
    e3.place(x=600,y=300)

    returndate=Label(top,text="Return Date",font=('time',20)).place(x=300,y=350)
    e4=Entry(top ,font=('time',20))
    e4.place(x=600,y=350)

    fine=Label(top,text="Fine",font=('time',20)).place(x=300,y=400)
    e5=Entry(top ,font=('time',20))
    e5.place(x=600,y=400)
    calculate=Button(top,text="CALCULATE",font=('time',15)).place(x=950,y=400)



    returndate=Button(top,text="return",font=('time',20),command=return1db).place(x=250,y=450)
    reset=Button(top,text="RESET",font=('time',20)).place(x=500,y=450)
    logout=Button(top,text="LOGOUT",font=('time',20)).place(x=700,y=450)
# return1()


top.mainloop()
