from tkinter import *
from tkinter.ttk import Combobox

top=Tk()
top.geometry("1500x1500")
top.title("return")
issuebook=Label(top,text="RETURN BOOKS",font=('time',20)).place(x=550,y=30)

studid=Label(top,text="Student Id",font=('time',20)).place(x=300,y=100)
stuid=['1','2','3','4','5']
combo2 = Combobox(top, values=stuid, font=('times', 20), state="readonly")
combo2.set("Select Id")
combo2.place(x=600, y=100)


studname=Label(top,text="Student Name",font=('time',20)).place(x=300,y=150)
e1=Entry(top ,font=('time',20)).place(x=600,y=150)

bookid=Label(top,text="Book Id",font=('time',20)).place(x=300,y=200)
book=["tamil","english","maths","science","social"]
combo1 = Combobox(top, values=book, font=('times', 20), state="readonly")
combo1.set("Select Department")
combo1.place(x=600, y=200)


bookname=Label(top,text="Book Name",font=('time',20)).place(x=300,y=250)

e2=Entry(top ,font=('time',20)).place(x=600,y=250)

issuedate=Label(top,text="Issue Date",font=('time',20)).place(x=300,y=300)
e3=Entry(top ,font=('time',20)).place(x=600,y=300)

returndate=Label(top,text="Return Date",font=('time',20)).place(x=300,y=350)
e4=Entry(top ,font=('time',20)).place(x=600,y=350)

fine=Label(top,text="Fine",font=('time',20)).place(x=300,y=400)
e5=Entry(top ,font=('time',20)).place(x=600,y=400)
calculate=Button(top,text="CALCULATE",font=('time',15)).place(x=950,y=400)



returndate=Button(top,text="RETURN DATE",font=('time',20)).place(x=250,y=450)
reset=Button(top,text="RESET",font=('time',20)).place(x=500,y=450)
logout=Button(top,text="LOGOUT",font=('time',20)).place(x=650,y=450)
top.mainloop()
