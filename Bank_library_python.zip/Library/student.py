from tkinter import *
from tkinter.ttk import Combobox

top=Tk()
top.geometry("1500x1500")
top.title("student")
login=Label(top,text="STUDENT DETAILS",font=('time',20)).place(x=550,y=30)

name=Label(top,text="NAME",font=('time',20)).place(x=300,y=100)
e1=Entry(top ,font=('time',20)).place(x=600,y=100)

department=Label(top,text="DEPARTMENT",font=('time',20)).place(x=300,y=150)
dep=["tamil","english","maths","science","social"]
combo1 = Combobox(top, values=dep, font=('times', 20), state="readonly")
combo1.set("Select Department")
combo1.place(x=600, y=150)

semester=Label(top,text="SEMESTER",font=('time',20)).place(x=300,y=200)
dep=["first","second","third","fourth","fifth"]
combo2 = Combobox(top, values=dep, font=('times', 20), state="readonly")
combo2.set("Select Semester")
combo2.place(x=600, y=200)

password=Label(top,text="PASSWORD",font=('time',20)).place(x=300,y=250)
e3=Entry(top ,font=('time',20)).place(x=600,y=250)

save=Button(top,text="SAVE",font=('time',20)).place(x=300,y=300)
reset=Button(top,text="RESET",font=('time',20)).place(x=450,y=300)
edit=Button(top,text="EDIT",font=('time',20)).place(x=600,y=300)
delete=Button(top,text="DELETE",font=('time',20)).place(x=750,y=300)
logout=Button(top,text="LOGOUT",font=('time',20)).place(x=900,y=300)
top.mainloop()
